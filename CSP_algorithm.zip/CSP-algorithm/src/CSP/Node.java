package CSP;

public class Node {
	private char letter;
	private int value;
	
	public Node(char c, int v) {
		this.letter = c;
		this.value = v;
	}

	public char getLetter() {
		return letter;
	}

	public void setLetter(char letter) {
		this.letter = letter;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
	
}
