package CSP;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
			Scanner myObj = new Scanner(System.in);  // Create a Scanner object
			System.out.println("Enter first word of cipher:");
			String firstWord = myObj.nextLine();
			System.out.println("Enter second word of cipher:");
			String secondWord = myObj.nextLine();
			System.out.println("Enter the result of cipher:");
			String result = myObj.nextLine();
			System.out.println("Enter in which arithmetic system to decipher:");
			int crypt_system = myObj.nextInt();
			myObj.close();
			Algorithm csp = new Algorithm(firstWord, secondWord, result, crypt_system); 
			if(!csp.assignWords(firstWord, secondWord, result)) {
				System.out.println("Solution not found.");
			}
			return;
	}

}
