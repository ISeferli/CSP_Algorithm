package CSP;

import java.util.Vector;
import java.util.HashMap;

public class Algorithm {
	private HashMap<Character, Integer> usedLetter;
	private Vector<Integer> use;
	private String firstWord;
	private String secondWord;
	private String result;
	private int crypt_system;
	
	public Algorithm(String f, String s, String result, int system) {
		this.firstWord = f;
		this.secondWord = s;
		this.result = result;
		this.crypt_system = system;
		this.usedLetter = new HashMap<Character, Integer>();
		this.use = new Vector<Integer>(this.getCrypt_system());
		for(int i=0; i<this.getCrypt_system(); i++) {
			use.add(0); //Initializing the array in a way that shows that none of the numbers are used
		}
	}
	
	
	public boolean assignWords(String first, String second, String res) {
		   int visitedChar = 0; //Number of the character that exist in the words

		   for(int i=0; i < first.length(); i++) {
			   if(!usedLetter.containsKey(first.charAt(i))) {
				   usedLetter.put(first.charAt(i), 1);
			   }
		   }
		   
		   for(int i=0; i < second.length(); i++) {
			   if(!usedLetter.containsKey(second.charAt(i))) {
				   usedLetter.put(second.charAt(i), 1);
			   }else {
				   usedLetter.put(second.charAt(i), usedLetter.get(second.charAt(i))+1);
			   }
		   }
		   
		   for(int i=0; i < res.length(); i++) {
			   if(!usedLetter.containsKey(res.charAt(i))) {
				   usedLetter.put(res.charAt(i), 1);
			   }else {
				   usedLetter.put(res.charAt(i), usedLetter.get(res.charAt(i))+1);
			   }
		   }

		   visitedChar = usedLetter.size();
		   
		   //If the available numbers, that are to be assigned for each character, are fewer than the characters, a solution can't be found 
		   if (visitedChar > this.crypt_system) { 
		      return false;
		   }

		   Node nodeList[] = new Node[visitedChar];
		   int j=0;
		   for(char i: usedLetter.keySet()) { //Assign all character found in the three strings
			   nodeList[j] = new Node(i, -1);
			   j++;
		   }
		   return backtracking(visitedChar, nodeList, 0, first, second, res);
	}
	
	
	private boolean backtracking(int visitedChar, Node[] list, int n, String first, String second, String res) {		
		if (n == visitedChar - 1) {     //When all characters have a number assigned to them
			for (int i = 0; i < this.crypt_system; i++) {
				if (use.get(i).equals(0)) {     // for those numbers, which are not used
					list[n].setValue(i);
					if (isValid(list, visitedChar, first, second, res)) { //Check if the solution is valid
						for (int j = 0; j < visitedChar; j++)    //Print solution
							System.out.println("" + list[j].getLetter() + " = " + list[j].getValue());
							return true;
						}
					}
				}
			return false;
		}

		for (int i = 0; i < this.crypt_system; i++) {
			if (use.get(i).equals(0)) {           // for those numbers, which are not used
				list[n].setValue(i);   //assign value i and mark as not available for future use
				use.set(i, 1);
				if (backtracking(visitedChar, list, n + 1, first, second, res)) //check next character
					return true;
				use.set(i, 0); //when backtracks, make available again
			}
		}
		return false;
	}
	
	
	private boolean isValid(Node[] nodeList, int count, String first, String second, String res) {
		int val1 = 0, val2 = 0, val3 = 0, m = 1, j, i;
		for (i = first.length() - 1; i >= 0; i--) {    
			char ch = first.charAt(i);
			for (j = 0; j < count; j++)
				if (nodeList[j].getLetter() == ch)       //when ch is present, break the loop
					break;
			val1 += m * nodeList[j].getValue();
			m *= this.getCrypt_system();
		}

		m = 1;
		for (i = second.length() - 1; i >= 0; i--) {    
			char ch = second.charAt(i);
			for (j = 0; j < count; j++)
				if (nodeList[j].getLetter() == ch)
					break;
			val2 += m * nodeList[j].getValue();
			m *= this.getCrypt_system();
		}

		m = 1;
		for (i = res.length() - 1; i >= 0; i--) {   
			char ch = res.charAt(i);
			for (j = 0; j < count; j++)
				if (nodeList[j].getLetter() == ch)
					break;
			val3 += m * nodeList[j].getValue();
			m *= this.getCrypt_system();
		}

		if (val3 == (val1 + val2))    //check whether the sum is same as 3rd string or not
			return true;
		return false;
	}

	public String getFirstWord() {
		return firstWord;
	}

	public void setFirstWord(String firstWord) {
		this.firstWord = firstWord;
	}

	public String getSecondWord() {
		return secondWord;
	}

	public void setSecondWord(String secondWord) {
		this.secondWord = secondWord;
	}
	
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public int getCrypt_system() {
		return crypt_system;
	}

	public void setCrypt_system(int crypt_system) {
		this.crypt_system = crypt_system;
	}

}
